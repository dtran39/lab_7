* pf_gui.py

    + script with GUI to test PF

* autograder.py 

    + see rubric inside
